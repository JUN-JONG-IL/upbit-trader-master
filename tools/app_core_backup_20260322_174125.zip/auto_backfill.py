﻿# shim loader for moved module: auto_backfill.py
# auto-generated to keep old imports working (loads from src\14_orchestrator)
import importlib.util
import sys
from pathlib import Path
import warnings

try:
    # repo root is three levels above src\app\core (parents[3])
    repo_root = Path(__file__).resolve().parents[3]
    mod_path = repo_root / 'src' / '14_orchestrator' / 'auto_backfill.py'
    spec = importlib.util.spec_from_file_location('moved_14_orchestrator.auto_backfill', str(mod_path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore
    # export public attributes into this module namespace
    for _k, _v in vars(mod).items():
        if not _k.startswith('__'):
            globals()[_k] = _v
    __wrapped_module__ = mod
except Exception as _e:
    warnings.warn(f'Failed to import moved module from {mod_path}: {_e}', RuntimeWarning)
    raise
